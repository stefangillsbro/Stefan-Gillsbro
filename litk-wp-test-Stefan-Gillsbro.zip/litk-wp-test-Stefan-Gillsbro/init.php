<?php
/*
Plugin Name: litk-wp-test-Stefan-Gillsbro
Description: This plugin display all subpages of the page it is placed on.
*/

function Show_All_Subpages($attributes = array(), $content) 
{
    //Add style sheet
    wp_register_style('my-plugin', plugins_url('litk-wp-test-Stefan-Gillsbro/css/style.css'));
    wp_enqueue_style('my-plugin');
	
    //Read the 'style' parameter of the content
    $attributes = shortcode_atts(array(
        'style' => '',
        'order' => 'ASC'
    ), $attributes);		
	
    extract($attributes);
	
    $myStyle = "style" + $style;
	
    //List od subpages	
    if ($post->post_parent) {
        $children = wp_list_pages(array(
            'title_li' => '',
            'child_of' => $post->post_parent,
            'echo'     => 0,
			'sort_order' => $order
        ));
    } else {
        $children = wp_list_pages(array(
            'title_li' => '',
            'child_of' => $post->ID,
            'echo'     => 0,
			'sort_order' => $order
        ));
    }
 
    //Add style according to content
    if ($children) :
        if($myStyle == '0')
            echo "<span>";
        else
            echo "<span class='StefansStyle$myStyle'>";	
        echo $children;
        ?> </span> <?php
    endif;
}

add_shortcode('StefanGillsbro', 'Show_All_Subpages');
?>